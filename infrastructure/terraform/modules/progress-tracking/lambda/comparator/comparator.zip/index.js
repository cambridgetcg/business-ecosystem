"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// comparator/index.ts
var comparator_exports = {};
__export(comparator_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(comparator_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_sns = require("@aws-sdk/client-sns");
var import_client_cloudwatch = require("@aws-sdk/client-cloudwatch");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var s3 = new import_client_s3.S3Client({});
var dynamodb = new import_client_dynamodb.DynamoDBClient({});
var sns = new import_client_sns.SNSClient({});
var cloudwatch = new import_client_cloudwatch.CloudWatchClient({});
var {
  S3_BUCKET,
  DYNAMODB_TABLE,
  MILESTONES_TABLE,
  SNS_MILESTONES_TOPIC,
  SNS_BLOCKERS_TOPIC,
  ENVIRONMENT
} = process.env;
async function getPreviousSnapshot() {
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const datePath = `${yesterday.getFullYear()}/${String(yesterday.getMonth() + 1).padStart(2, "0")}/${String(yesterday.getDate()).padStart(2, "0")}`;
  try {
    const response = await s3.send(
      new import_client_s3.GetObjectCommand({
        Bucket: S3_BUCKET,
        Key: `snapshots/${datePath}/ecosystem-status.json`
      })
    );
    const body = await response.Body?.transformToString();
    return body ? JSON.parse(body) : null;
  } catch (error) {
    if (error.name === "NoSuchKey") {
      console.log("No previous snapshot found");
      return null;
    }
    throw error;
  }
}
async function getCurrentSnapshot(key) {
  const response = await s3.send(
    new import_client_s3.GetObjectCommand({
      Bucket: S3_BUCKET,
      Key: key
    })
  );
  const body = await response.Body?.transformToString();
  return JSON.parse(body);
}
function detectMilestones(previous, current) {
  const milestones = [];
  if (!previous) {
    return milestones;
  }
  for (const [path, currentApp] of Object.entries(current.apps)) {
    const previousApp = previous.apps[path];
    if (!previousApp) {
      if (currentApp.progress > 0) {
        milestones.push({
          app: path,
          type: "progress_milestone",
          description: `New app ${currentApp.name} added with ${Math.round(currentApp.progress * 100)}% progress`,
          newValue: currentApp.progress
        });
      }
      continue;
    }
    if (currentApp.currentWaypoint !== previousApp.currentWaypoint && previousApp.currentWaypoint) {
      milestones.push({
        app: path,
        type: "waypoint_complete",
        description: `${currentApp.name} completed waypoint ${previousApp.currentWaypoint}`,
        oldValue: previousApp.currentWaypoint,
        newValue: currentApp.currentWaypoint
      });
    }
    const statusOrder = ["placeholder", "skeleton", "active", "ready"];
    const previousIndex = statusOrder.indexOf(previousApp.status);
    const currentIndex = statusOrder.indexOf(currentApp.status);
    if (currentIndex > previousIndex) {
      milestones.push({
        app: path,
        type: "status_promotion",
        description: `${currentApp.name} promoted from ${previousApp.status} to ${currentApp.status}`,
        oldValue: previousApp.status,
        newValue: currentApp.status
      });
    }
    const progressMilestones = [0.25, 0.5, 0.75, 1];
    for (const milestone of progressMilestones) {
      if (previousApp.progress < milestone && currentApp.progress >= milestone) {
        milestones.push({
          app: path,
          type: "progress_milestone",
          description: `${currentApp.name} reached ${Math.round(milestone * 100)}% progress`,
          oldValue: previousApp.progress,
          newValue: currentApp.progress
        });
      }
    }
  }
  return milestones;
}
function detectNewBlockers(previous, current) {
  const newBlockers = [];
  if (!previous)
    return newBlockers;
  for (const [path, currentApp] of Object.entries(current.apps)) {
    const previousApp = previous.apps[path];
    const previousBlockers = previousApp?.blockers || [];
    const addedBlockers = currentApp.blockers.filter(
      (b) => !previousBlockers.includes(b)
    );
    if (addedBlockers.length > 0) {
      newBlockers.push({
        app: path,
        blockers: addedBlockers
      });
    }
  }
  return newBlockers;
}
async function recordMilestone(milestone) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  await dynamodb.send(
    new import_client_dynamodb.PutItemCommand({
      TableName: MILESTONES_TABLE,
      Item: (0, import_util_dynamodb.marshall)({
        pk: `APP#${milestone.app}`,
        sk: `MILESTONE#${timestamp}`,
        eventType: milestone.type,
        description: milestone.description,
        oldValue: milestone.oldValue,
        newValue: milestone.newValue,
        timestamp,
        ttl: Math.floor(Date.now() / 1e3) + 2 * 365 * 24 * 60 * 60
        // 2 years
      })
    })
  );
}
async function publishMilestoneNotification(milestones) {
  if (milestones.length === 0)
    return;
  await cloudwatch.send(
    new import_client_cloudwatch.PutMetricDataCommand({
      Namespace: "EcosystemProgress",
      MetricData: [
        {
          MetricName: "MilestonesCompleted",
          Value: milestones.length,
          Unit: "Count",
          Timestamp: /* @__PURE__ */ new Date(),
          Dimensions: [{ Name: "Environment", Value: ENVIRONMENT }]
        }
      ]
    })
  );
  await sns.send(
    new import_client_sns.PublishCommand({
      TopicArn: SNS_MILESTONES_TOPIC,
      Subject: `[MILESTONE] ${milestones.length} milestone(s) achieved`,
      Message: JSON.stringify({
        type: "milestones",
        count: milestones.length,
        milestones: milestones.map((m) => ({
          app: m.app,
          type: m.type,
          description: m.description
        })),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }),
      MessageAttributes: {
        eventType: { DataType: "String", StringValue: "milestone" },
        count: { DataType: "Number", StringValue: String(milestones.length) }
      }
    })
  );
}
async function publishBlockerNotification(blockers) {
  if (blockers.length === 0)
    return;
  await sns.send(
    new import_client_sns.PublishCommand({
      TopicArn: SNS_BLOCKERS_TOPIC,
      Subject: `[BLOCKER] New blockers detected in ${blockers.length} app(s)`,
      Message: JSON.stringify({
        type: "new_blockers",
        count: blockers.length,
        blockers: blockers.map((b) => ({
          app: b.app,
          blockers: b.blockers
        })),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }),
      MessageAttributes: {
        eventType: { DataType: "String", StringValue: "blocker" },
        count: { DataType: "Number", StringValue: String(blockers.length) }
      }
    })
  );
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  const record = event.Records?.[0];
  if (!record) {
    console.log("No S3 record found");
    return;
  }
  const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
  console.log(`Processing snapshot: ${key}`);
  if (key.includes("/latest/")) {
    console.log("Skipping latest snapshot");
    return;
  }
  try {
    const current = await getCurrentSnapshot(key);
    const previous = await getPreviousSnapshot();
    const milestones = detectMilestones(previous, current);
    console.log(`Detected ${milestones.length} milestones`);
    for (const milestone of milestones) {
      await recordMilestone(milestone);
    }
    await publishMilestoneNotification(milestones);
    const newBlockers = detectNewBlockers(previous, current);
    await publishBlockerNotification(newBlockers);
    console.log("Comparison complete");
  } catch (error) {
    console.error("Comparator error:", error);
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
