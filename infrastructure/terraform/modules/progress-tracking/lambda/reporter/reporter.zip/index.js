"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// reporter/index.ts
var reporter_exports = {};
__export(reporter_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(reporter_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_sns = require("@aws-sdk/client-sns");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var s3 = new import_client_s3.S3Client({});
var dynamodb = new import_client_dynamodb.DynamoDBClient({});
var sns = new import_client_sns.SNSClient({});
var {
  S3_BUCKET,
  DYNAMODB_TABLE,
  MILESTONES_TABLE,
  SNS_WEEKLY_TOPIC,
  NOTIFICATION_EMAIL,
  ENVIRONMENT
} = process.env;
async function getSnapshotsForPeriod(startDate, endDate) {
  const snapshots = [];
  let currentDate = new Date(startDate);
  while (currentDate <= endDate) {
    const datePath = `${currentDate.getFullYear()}/${String(currentDate.getMonth() + 1).padStart(2, "0")}/${String(currentDate.getDate()).padStart(2, "0")}`;
    const key = `snapshots/${datePath}/ecosystem-status.json`;
    try {
      const response = await s3.send(
        new import_client_s3.GetObjectCommand({
          Bucket: S3_BUCKET,
          Key: key
        })
      );
      const body = await response.Body?.transformToString();
      if (body) {
        snapshots.push({
          date: currentDate.toISOString().split("T")[0],
          data: JSON.parse(body)
        });
      }
    } catch (error) {
      if (error.name !== "NoSuchKey") {
        console.warn(`Error fetching snapshot for ${datePath}:`, error);
      }
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }
  return snapshots;
}
async function getMilestonesForPeriod(startDate, endDate) {
  const milestones = [];
  const result = await dynamodb.send(
    new import_client_dynamodb.ScanCommand({
      TableName: MILESTONES_TABLE,
      FilterExpression: "#ts BETWEEN :start AND :end",
      ExpressionAttributeNames: {
        "#ts": "timestamp"
      },
      ExpressionAttributeValues: (0, import_util_dynamodb.marshall)({
        ":start": startDate.toISOString(),
        ":end": endDate.toISOString()
      })
    })
  );
  for (const item of result.Items || []) {
    milestones.push((0, import_util_dynamodb.unmarshall)(item));
  }
  return milestones.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}
async function generateReportData(type) {
  const endDate = /* @__PURE__ */ new Date();
  const startDate = /* @__PURE__ */ new Date();
  if (type === "weekly") {
    startDate.setDate(startDate.getDate() - 7);
  } else {
    startDate.setMonth(startDate.getMonth() - 1);
  }
  const snapshots = await getSnapshotsForPeriod(startDate, endDate);
  if (snapshots.length === 0) {
    throw new Error("No snapshots found for the period");
  }
  const firstSnapshot = snapshots[0].data;
  const lastSnapshot = snapshots[snapshots.length - 1].data;
  const milestones = await getMilestonesForPeriod(startDate, endDate);
  const progressChange = lastSnapshot.summary.overallProgress - firstSnapshot.summary.overallProgress;
  const layers = ["foundational", "operational", "gateway"];
  const byLayer = {};
  for (const layer of layers) {
    const firstLayerApps = Object.values(firstSnapshot.apps).filter(
      (a) => a.layer === layer
    );
    const lastLayerApps = Object.values(lastSnapshot.apps).filter(
      (a) => a.layer === layer
    );
    const firstProgress = firstLayerApps.reduce((sum, a) => sum + a.progress, 0) / (firstLayerApps.length || 1);
    const lastProgress = lastLayerApps.reduce((sum, a) => sum + a.progress, 0) / (lastLayerApps.length || 1);
    byLayer[layer] = {
      progress: lastProgress,
      progressChange: lastProgress - firstProgress,
      appsCount: lastLayerApps.length
    };
  }
  const topPerformers = [];
  for (const [path, lastApp] of Object.entries(lastSnapshot.apps)) {
    const firstApp = firstSnapshot.apps[path];
    if (firstApp) {
      const gain = lastApp.progress - firstApp.progress;
      if (gain > 0) {
        topPerformers.push({
          app: path,
          name: lastApp.name,
          progressGain: gain
        });
      }
    }
  }
  topPerformers.sort((a, b) => b.progressGain - a.progressGain);
  const needsAttention = [];
  for (const [path, app] of Object.entries(lastSnapshot.apps)) {
    if (app.blockers && app.blockers.length > 0) {
      needsAttention.push({
        app: path,
        name: app.name,
        reason: `Has ${app.blockers.length} blocker(s): ${app.blockers.join(", ")}`
      });
    }
    const firstApp = firstSnapshot.apps[path];
    if (firstApp && app.progress < firstApp.progress) {
      needsAttention.push({
        app: path,
        name: app.name,
        reason: `Progress decreased from ${Math.round(firstApp.progress * 100)}% to ${Math.round(app.progress * 100)}%`
      });
    }
    if (app.status === "active") {
      const lastActivity = new Date(app.lastActivity);
      const daysSinceActivity = Math.floor(
        (Date.now() - lastActivity.getTime()) / (1e3 * 60 * 60 * 24)
      );
      if (daysSinceActivity > 14) {
        needsAttention.push({
          app: path,
          name: app.name,
          reason: `No activity for ${daysSinceActivity} days`
        });
      }
    }
  }
  let newBlockers = 0;
  let blockersResolved = 0;
  for (const [path, lastApp] of Object.entries(lastSnapshot.apps)) {
    const firstApp = firstSnapshot.apps[path];
    if (firstApp) {
      const firstBlockers = firstApp.blockers || [];
      const lastBlockers = lastApp.blockers || [];
      newBlockers += lastBlockers.filter(
        (b) => !firstBlockers.includes(b)
      ).length;
      blockersResolved += firstBlockers.filter(
        (b) => !lastBlockers.includes(b)
      ).length;
    }
  }
  let appsAdvanced = 0;
  const statusOrder = ["placeholder", "skeleton", "active", "ready"];
  for (const [path, lastApp] of Object.entries(lastSnapshot.apps)) {
    const firstApp = firstSnapshot.apps[path];
    if (firstApp) {
      const firstIndex = statusOrder.indexOf(firstApp.status);
      const lastIndex = statusOrder.indexOf(lastApp.status);
      if (lastIndex > firstIndex)
        appsAdvanced++;
    }
  }
  const recommendations = [];
  if (progressChange < 0) {
    recommendations.push(
      "Overall progress has decreased. Review apps with regression and identify root causes."
    );
  }
  if (needsAttention.filter((a) => a.reason.includes("blocker")).length > 3) {
    recommendations.push(
      "Multiple apps have blockers. Consider a blocker review session to unblock progress."
    );
  }
  if (topPerformers.length === 0) {
    recommendations.push(
      "No significant progress this period. Consider reviewing priorities and resource allocation."
    );
  }
  const skeletonApps = Object.values(lastSnapshot.apps).filter(
    (a) => a.status === "skeleton" || a.status === "placeholder"
  ).length;
  if (skeletonApps > lastSnapshot.summary.totalApps / 2) {
    recommendations.push(
      `${skeletonApps} apps are still skeleton/placeholder. Consider focusing on fewer apps to completion.`
    );
  }
  return {
    period: {
      start: startDate.toISOString().split("T")[0],
      end: endDate.toISOString().split("T")[0],
      type
    },
    summary: {
      overallProgress: lastSnapshot.summary.overallProgress,
      progressChange,
      milestonesCompleted: milestones.filter(
        (m) => ["waypoint_complete", "status_promotion", "progress_milestone"].includes(
          m.eventType
        )
      ).length,
      newBlockers,
      blockersResolved,
      appsAdvanced
    },
    byLayer,
    topPerformers: topPerformers.slice(0, 5),
    needsAttention: needsAttention.slice(0, 10),
    milestones: milestones.slice(0, 10).map((m) => ({
      app: m.pk.replace("APP#", ""),
      description: m.description,
      timestamp: m.timestamp
    })),
    recommendations
  };
}
function formatReportMarkdown(report) {
  const progressBar = (pct) => {
    const filled = Math.round(pct * 10);
    return "\u2588".repeat(filled) + "\u2591".repeat(10 - filled);
  };
  const changeSymbol = (change) => {
    if (change > 0)
      return `+${Math.round(change * 100)}% \u2191`;
    if (change < 0)
      return `${Math.round(change * 100)}% \u2193`;
    return "0%";
  };
  let md = `# Progress Report: ${report.period.type === "weekly" ? "Weekly" : "Monthly"}

**Period**: ${report.period.start} to ${report.period.end}
**Generated**: ${(/* @__PURE__ */ new Date()).toISOString()}

---

## Executive Summary

| Metric | Value |
|--------|-------|
| Overall Progress | ${progressBar(report.summary.overallProgress)} ${Math.round(report.summary.overallProgress * 100)}% |
| Progress Change | ${changeSymbol(report.summary.progressChange)} |
| Milestones Completed | ${report.summary.milestonesCompleted} |
| Apps Advanced | ${report.summary.appsAdvanced} |
| New Blockers | ${report.summary.newBlockers} |
| Blockers Resolved | ${report.summary.blockersResolved} |

---

## Progress by Layer

| Layer | Progress | Change |
|-------|----------|--------|
`;
  for (const [layer, data] of Object.entries(report.byLayer)) {
    md += `| ${layer} | ${progressBar(data.progress)} ${Math.round(data.progress * 100)}% | ${changeSymbol(data.progressChange)} |
`;
  }
  md += `
---

## Top Performers

`;
  if (report.topPerformers.length > 0) {
    md += `| App | Progress Gain |
|-----|---------------|
`;
    for (const performer of report.topPerformers) {
      md += `| ${performer.name} | +${Math.round(performer.progressGain * 100)}% |
`;
    }
  } else {
    md += `*No significant progress gains this period.*
`;
  }
  md += `
---

## Needs Attention

`;
  if (report.needsAttention.length > 0) {
    md += `| App | Issue |
|-----|-------|
`;
    for (const item of report.needsAttention) {
      md += `| ${item.name} | ${item.reason} |
`;
    }
  } else {
    md += `*All apps are on track.*
`;
  }
  md += `
---

## Recent Milestones

`;
  if (report.milestones.length > 0) {
    for (const milestone of report.milestones) {
      md += `- **${milestone.app}**: ${milestone.description} (${milestone.timestamp.split("T")[0]})
`;
    }
  } else {
    md += `*No milestones this period.*
`;
  }
  if (report.recommendations.length > 0) {
    md += `
---

## Recommendations

`;
    for (const rec of report.recommendations) {
      md += `- ${rec}
`;
    }
  }
  md += `
---

*Generated by Ecosystem Progress Tracker*
`;
  return md;
}
async function saveReport(report, markdown) {
  const date = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const prefix = report.period.type === "weekly" ? "weekly" : "monthly";
  const key = `reports/${prefix}/${date}.md`;
  await s3.send(
    new import_client_s3.PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: key,
      Body: markdown,
      ContentType: "text/markdown"
    })
  );
  await s3.send(
    new import_client_s3.PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: key.replace(".md", ".json"),
      Body: JSON.stringify(report, null, 2),
      ContentType: "application/json"
    })
  );
  return key;
}
async function publishReportNotification(report, markdown, s3Key) {
  const subject = report.period.type === "weekly" ? `[WEEKLY] Ecosystem Progress Report (${report.period.start} - ${report.period.end})` : `[MONTHLY] Ecosystem Progress Report (${report.period.start} - ${report.period.end})`;
  await sns.send(
    new import_client_sns.PublishCommand({
      TopicArn: SNS_WEEKLY_TOPIC,
      Subject: subject,
      Message: JSON.stringify({
        type: "report",
        reportType: report.period.type,
        period: report.period,
        summary: report.summary,
        s3Key,
        markdown: markdown.substring(0, 1e4),
        // Truncate for SNS limit
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }),
      MessageAttributes: {
        eventType: { DataType: "String", StringValue: "report" },
        reportType: { DataType: "String", StringValue: report.period.type }
      }
    })
  );
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  const reportType = event.reportType || "weekly";
  try {
    console.log(`Generating ${reportType} report...`);
    const report = await generateReportData(reportType);
    const markdown = formatReportMarkdown(report);
    const s3Key = await saveReport(report, markdown);
    console.log(`Report saved to: ${s3Key}`);
    await publishReportNotification(report, markdown, s3Key);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `${reportType} report generated successfully`,
        s3Key,
        summary: report.summary
      })
    };
  } catch (error) {
    console.error("Reporter error:", error);
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
