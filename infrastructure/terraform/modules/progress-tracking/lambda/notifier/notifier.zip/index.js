"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// notifier/index.ts
var notifier_exports = {};
__export(notifier_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(notifier_exports);
var import_client_secrets_manager = require("@aws-sdk/client-secrets-manager");
var import_client_ses = require("@aws-sdk/client-ses");
var secrets = new import_client_secrets_manager.SecretsManagerClient({});
var ses = new import_client_ses.SESClient({});
var {
  SECRET_NAME,
  ENABLE_SLACK,
  ENABLE_EMAIL,
  NOTIFICATION_EMAIL,
  FROM_EMAIL,
  ENVIRONMENT
} = process.env;
async function getSlackWebhookUrl() {
  if (ENABLE_SLACK !== "true")
    return null;
  try {
    const response = await secrets.send(
      new import_client_secrets_manager.GetSecretValueCommand({ SecretId: SECRET_NAME })
    );
    const secret = JSON.parse(response.SecretString || "{}");
    return secret.url || null;
  } catch (error) {
    console.warn("Could not retrieve Slack webhook:", error);
    return null;
  }
}
function formatSlackMessage(payload) {
  const blocks = [];
  switch (payload.type) {
    case "milestones":
      blocks.push({
        type: "header",
        text: {
          type: "plain_text",
          text: `\u{1F389} ${payload.count} Milestone(s) Achieved!`,
          emoji: true
        }
      });
      for (const milestone of payload.milestones || []) {
        blocks.push({
          type: "section",
          text: {
            type: "mrkdwn",
            text: `*${milestone.app}*
${milestone.description}`
          }
        });
      }
      break;
    case "new_blockers":
      blocks.push({
        type: "header",
        text: {
          type: "plain_text",
          text: `\u26A0\uFE0F New Blockers Detected`,
          emoji: true
        }
      });
      for (const item of payload.blockers || []) {
        blocks.push({
          type: "section",
          text: {
            type: "mrkdwn",
            text: `*${item.app}*
Blockers: ${item.blockers.join(", ")}`
          }
        });
      }
      break;
    case "stale_apps":
      blocks.push({
        type: "header",
        text: {
          type: "plain_text",
          text: `\u23F0 ${payload.count} Stale Apps Detected`,
          emoji: true
        }
      });
      const staleList = (payload.apps || []).map((a) => `\u2022 ${a.name} (last active: ${a.lastActivity})`).join("\n");
      blocks.push({
        type: "section",
        text: {
          type: "mrkdwn",
          text: staleList || "No details available"
        }
      });
      break;
    case "report":
      blocks.push({
        type: "header",
        text: {
          type: "plain_text",
          text: `\u{1F4CA} ${payload.reportType === "weekly" ? "Weekly" : "Monthly"} Progress Report`,
          emoji: true
        }
      });
      if (payload.summary) {
        const progressPct = Math.round(payload.summary.overallProgress * 100);
        const changePct = Math.round(payload.summary.progressChange * 100);
        const changeStr = changePct >= 0 ? `+${changePct}%` : `${changePct}%`;
        blocks.push({
          type: "section",
          fields: [
            {
              type: "mrkdwn",
              text: `*Overall Progress*
${progressPct}% (${changeStr})`
            },
            {
              type: "mrkdwn",
              text: `*Milestones*
${payload.summary.milestonesCompleted}`
            },
            {
              type: "mrkdwn",
              text: `*Apps Advanced*
${payload.summary.appsAdvanced}`
            },
            {
              type: "mrkdwn",
              text: `*Blockers*
+${payload.summary.newBlockers} / -${payload.summary.blockersResolved}`
            }
          ]
        });
      }
      break;
    case "regression":
    case "status_change":
    case "blocker_change":
      const severity = payload.severity === "warning" ? "\u26A0\uFE0F" : "\u2139\uFE0F";
      blocks.push({
        type: "section",
        text: {
          type: "mrkdwn",
          text: `${severity} *${payload.app}*
${payload.details}`
        }
      });
      break;
    default:
      blocks.push({
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*Notification*
${JSON.stringify(payload, null, 2)}`
        }
      });
  }
  blocks.push({
    type: "context",
    elements: [
      {
        type: "mrkdwn",
        text: `Environment: ${ENVIRONMENT} | ${(/* @__PURE__ */ new Date()).toISOString()}`
      }
    ]
  });
  return { blocks };
}
async function sendSlackNotification(webhookUrl, payload) {
  const message = formatSlackMessage(payload);
  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(message)
  });
  if (!response.ok) {
    throw new Error(`Slack API error: ${response.status}`);
  }
}
function formatEmailMessage(payload) {
  let subject = "";
  let html = "";
  let text = "";
  switch (payload.type) {
    case "milestones":
      subject = `[Ecosystem] ${payload.count} Milestone(s) Achieved`;
      html = `
        <h2>\u{1F389} Milestones Achieved</h2>
        <ul>
          ${(payload.milestones || []).map((m) => `<li><strong>${m.app}</strong>: ${m.description}</li>`).join("")}
        </ul>
      `;
      text = (payload.milestones || []).map((m) => `${m.app}: ${m.description}`).join("\n");
      break;
    case "new_blockers":
      subject = `[Ecosystem] New Blockers Detected`;
      html = `
        <h2>\u26A0\uFE0F New Blockers</h2>
        <ul>
          ${(payload.blockers || []).map((b) => `<li><strong>${b.app}</strong>: ${b.blockers.join(", ")}</li>`).join("")}
        </ul>
      `;
      text = (payload.blockers || []).map((b) => `${b.app}: ${b.blockers.join(", ")}`).join("\n");
      break;
    case "stale_apps":
      subject = `[Ecosystem] ${payload.count} Stale Apps Detected`;
      html = `
        <h2>\u23F0 Stale Apps</h2>
        <p>The following active apps have had no activity for ${payload.staleDays}+ days:</p>
        <ul>
          ${(payload.apps || []).map((a) => `<li><strong>${a.name}</strong> (last: ${a.lastActivity})</li>`).join("")}
        </ul>
      `;
      text = (payload.apps || []).map((a) => `${a.name}: last active ${a.lastActivity}`).join("\n");
      break;
    case "report":
      subject = `[Ecosystem] ${payload.reportType === "weekly" ? "Weekly" : "Monthly"} Progress Report`;
      if (payload.markdown) {
        html = `
          <h2>\u{1F4CA} Progress Report</h2>
          <p><strong>Period:</strong> ${payload.period?.start} to ${payload.period?.end}</p>
          <h3>Summary</h3>
          <ul>
            <li>Overall Progress: ${Math.round((payload.summary?.overallProgress || 0) * 100)}%</li>
            <li>Progress Change: ${Math.round((payload.summary?.progressChange || 0) * 100)}%</li>
            <li>Milestones: ${payload.summary?.milestonesCompleted || 0}</li>
            <li>Apps Advanced: ${payload.summary?.appsAdvanced || 0}</li>
          </ul>
          <pre>${payload.markdown}</pre>
        `;
        text = payload.markdown;
      }
      break;
    default:
      subject = `[Ecosystem] Progress Notification`;
      html = `<pre>${JSON.stringify(payload, null, 2)}</pre>`;
      text = JSON.stringify(payload, null, 2);
  }
  html += `
    <hr>
    <p style="color: #666; font-size: 12px;">
      Environment: ${ENVIRONMENT} | ${(/* @__PURE__ */ new Date()).toISOString()}<br>
      Ecosystem Progress Tracker
    </p>
  `;
  return { subject, html, text };
}
async function sendEmailNotification(payload) {
  if (!NOTIFICATION_EMAIL) {
    console.log("No notification email configured");
    return;
  }
  const { subject, html, text } = formatEmailMessage(payload);
  await ses.send(
    new import_client_ses.SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [NOTIFICATION_EMAIL]
      },
      Message: {
        Subject: { Data: subject },
        Body: {
          Html: { Data: html },
          Text: { Data: text }
        }
      }
    })
  );
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  for (const record of event.Records || []) {
    if (record.EventSource !== "aws:sns")
      continue;
    const message = record.Sns.Message;
    let payload;
    try {
      payload = JSON.parse(message);
    } catch {
      payload = { type: "unknown", message };
    }
    console.log("Processing notification:", payload.type);
    if (ENABLE_SLACK === "true") {
      const webhookUrl = await getSlackWebhookUrl();
      if (webhookUrl) {
        try {
          await sendSlackNotification(webhookUrl, payload);
          console.log("Slack notification sent");
        } catch (error) {
          console.error("Slack notification error:", error);
        }
      }
    }
    if (ENABLE_EMAIL === "true") {
      try {
        await sendEmailNotification(payload);
        console.log("Email notification sent");
      } catch (error) {
        console.error("Email notification error:", error);
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
