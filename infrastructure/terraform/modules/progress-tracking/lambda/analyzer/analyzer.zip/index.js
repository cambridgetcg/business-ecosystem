"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// analyzer/index.ts
var analyzer_exports = {};
__export(analyzer_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(analyzer_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_sns = require("@aws-sdk/client-sns");
var import_client_cloudwatch = require("@aws-sdk/client-cloudwatch");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var dynamodb = new import_client_dynamodb.DynamoDBClient({});
var sns = new import_client_sns.SNSClient({});
var cloudwatch = new import_client_cloudwatch.CloudWatchClient({});
var {
  DYNAMODB_TABLE,
  MILESTONES_TABLE,
  SNS_ALERTS_TOPIC,
  ENVIRONMENT
} = process.env;
function analyzeChange(oldImage, newImage) {
  const oldProgress = oldImage?.progress || 0;
  const newProgress = newImage?.progress || 0;
  const oldStatus = oldImage?.status;
  const newStatus = newImage?.status;
  const oldBlockers = oldImage?.blockers || [];
  const newBlockers = newImage?.blockers || [];
  if (newProgress < oldProgress - 0.05) {
    return {
      type: "regression",
      details: `Progress decreased from ${Math.round(oldProgress * 100)}% to ${Math.round(newProgress * 100)}%`,
      severity: "warning"
    };
  }
  if (newProgress >= oldProgress + 0.1) {
    return {
      type: "improvement",
      details: `Progress increased from ${Math.round(oldProgress * 100)}% to ${Math.round(newProgress * 100)}%`,
      severity: "info"
    };
  }
  if (oldStatus !== newStatus) {
    const isPromotion = oldStatus === "placeholder" && newStatus !== "placeholder" || oldStatus === "skeleton" && ["active", "ready"].includes(newStatus) || oldStatus === "active" && newStatus === "ready";
    return {
      type: "status_change",
      details: `Status changed from ${oldStatus} to ${newStatus}`,
      severity: isPromotion ? "info" : "warning"
    };
  }
  const newBlockerAdded = newBlockers.some((b) => !oldBlockers.includes(b));
  if (newBlockerAdded) {
    return {
      type: "blocker_change",
      details: `New blocker added: ${newBlockers.filter((b) => !oldBlockers.includes(b)).join(", ")}`,
      severity: "warning"
    };
  }
  return { type: "none", details: "", severity: "info" };
}
async function recordEvent(app, eventType, details, severity) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  await dynamodb.send(
    new import_client_dynamodb.PutItemCommand({
      TableName: MILESTONES_TABLE,
      Item: (0, import_util_dynamodb.marshall)({
        pk: `APP#${app}`,
        sk: `EVENT#${timestamp}`,
        eventType,
        details,
        severity,
        timestamp,
        ttl: Math.floor(Date.now() / 1e3) + 365 * 24 * 60 * 60
      })
    })
  );
}
async function processStreamRecords(records) {
  for (const record of records) {
    if (record.eventName === "REMOVE")
      continue;
    const newImage = record.dynamodb.NewImage ? (0, import_util_dynamodb.unmarshall)(record.dynamodb.NewImage) : null;
    const oldImage = record.dynamodb.OldImage ? (0, import_util_dynamodb.unmarshall)(record.dynamodb.OldImage) : null;
    if (!newImage)
      continue;
    if (!newImage.pk?.startsWith("APP#") || newImage.sk !== "STATUS")
      continue;
    const appPath = newImage.pk.replace("APP#", "");
    if (oldImage) {
      const change = analyzeChange(oldImage, newImage);
      if (change.type !== "none") {
        console.log(`Change detected for ${appPath}:`, change);
        await recordEvent(appPath, change.type, change.details, change.severity);
        if (change.severity !== "info") {
          await sns.send(
            new import_client_sns.PublishCommand({
              TopicArn: SNS_ALERTS_TOPIC,
              Subject: `[${change.severity.toUpperCase()}] Progress Alert: ${appPath}`,
              Message: JSON.stringify({
                app: appPath,
                type: change.type,
                details: change.details,
                severity: change.severity,
                timestamp: (/* @__PURE__ */ new Date()).toISOString(),
                oldProgress: oldImage.progress,
                newProgress: newImage.progress
              }),
              MessageAttributes: {
                eventType: { DataType: "String", StringValue: change.type },
                severity: { DataType: "String", StringValue: change.severity }
              }
            })
          );
        }
      }
    }
  }
}
async function checkStaleApps(staleDays) {
  const cutoffDate = /* @__PURE__ */ new Date();
  cutoffDate.setDate(cutoffDate.getDate() - staleDays);
  const cutoffStr = cutoffDate.toISOString().split("T")[0];
  const result = await dynamodb.send(
    new import_client_dynamodb.QueryCommand({
      TableName: DYNAMODB_TABLE,
      IndexName: "gsi2-status-activity",
      KeyConditionExpression: "gsi2pk = :status AND gsi2sk < :cutoff",
      ExpressionAttributeValues: (0, import_util_dynamodb.marshall)({
        ":status": "active",
        ":cutoff": cutoffStr
      })
    })
  );
  const staleApps = (result.Items || []).map((item) => (0, import_util_dynamodb.unmarshall)(item));
  if (staleApps.length > 0) {
    console.log(`Found ${staleApps.length} stale apps`);
    await cloudwatch.send(
      new import_client_cloudwatch.PutMetricDataCommand({
        Namespace: "EcosystemProgress",
        MetricData: [
          {
            MetricName: "StaleApps",
            Value: staleApps.length,
            Unit: "Count",
            Timestamp: /* @__PURE__ */ new Date(),
            Dimensions: [{ Name: "Environment", Value: ENVIRONMENT }]
          }
        ]
      })
    );
    await sns.send(
      new import_client_sns.PublishCommand({
        TopicArn: SNS_ALERTS_TOPIC,
        Subject: `[WARNING] ${staleApps.length} Stale Apps Detected`,
        Message: JSON.stringify({
          type: "stale_apps",
          count: staleApps.length,
          apps: staleApps.map((a) => ({
            path: a.path,
            name: a.name,
            lastActivity: a.lastActivity,
            progress: a.progress
          })),
          staleDays,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }),
        MessageAttributes: {
          eventType: { DataType: "String", StringValue: "stale_apps" },
          severity: { DataType: "String", StringValue: "warning" }
        }
      })
    );
  }
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  if (event.source === "scheduled" && event.action === "stale_check") {
    const staleDays = event.staleDays || 14;
    await checkStaleApps(staleDays);
    return;
  }
  if (event.Records) {
    await processStreamRecords(event.Records);
    return;
  }
  console.log("Unknown event type");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
