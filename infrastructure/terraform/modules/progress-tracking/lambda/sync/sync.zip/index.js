"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// sync/index.ts
var sync_exports = {};
__export(sync_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sync_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_secrets_manager = require("@aws-sdk/client-secrets-manager");
var import_client_cloudwatch = require("@aws-sdk/client-cloudwatch");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var s3 = new import_client_s3.S3Client({});
var dynamodb = new import_client_dynamodb.DynamoDBClient({});
var secrets = new import_client_secrets_manager.SecretsManagerClient({});
var cloudwatch = new import_client_cloudwatch.CloudWatchClient({});
var {
  S3_BUCKET,
  DYNAMODB_TABLE,
  MILESTONES_TABLE,
  GITHUB_REPO,
  GITHUB_BRANCH,
  SECRET_NAME,
  ENVIRONMENT
} = process.env;
async function getGitHubToken() {
  const response = await secrets.send(
    new import_client_secrets_manager.GetSecretValueCommand({ SecretId: SECRET_NAME })
  );
  const secret = JSON.parse(response.SecretString || "{}");
  return secret.token;
}
async function fetchFromGitHub(path, token) {
  const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${path}?ref=${GITHUB_BRANCH}`;
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github.v3.raw"
    }
  });
  if (!response.ok) {
    if (response.status === 404)
      return null;
    throw new Error(`GitHub API error: ${response.status}`);
  }
  return response.text();
}
function parseStatusFile(content, appPath) {
  const result = {
    path: appPath,
    layer: appPath.split("/")[0]
  };
  const titleMatch = content.match(/^#\s+(.+?)\s+Status/m);
  if (titleMatch) {
    result.name = titleMatch[1];
  }
  const statusMatch = content.match(/\*\*Status\*\*:\s*(Ready|Active|Skeleton|Placeholder)/i);
  if (statusMatch) {
    result.status = statusMatch[1].toLowerCase();
  }
  const progressMatch = content.match(/Overall Progress\s*\|\s*(\d+)%/);
  if (progressMatch) {
    result.progress = parseInt(progressMatch[1], 10) / 100;
  }
  const waypointMatch = content.match(/Current Waypoint\s*\|\s*([^|]+)/);
  if (waypointMatch) {
    const wp = waypointMatch[1].trim();
    if (wp && wp !== "-" && wp !== "Not started" && wp !== "Maintenance") {
      result.currentWaypoint = wp.split(":")[0].trim();
      result.waypointName = wp.includes(":") ? wp.split(":")[1].trim() : wp;
    } else if (wp === "Maintenance") {
      result.waypointName = "Maintenance";
    }
  }
  const blockersMatch = content.match(/Blockers\s*\|\s*([^|]+)/);
  if (blockersMatch) {
    const blockers = blockersMatch[1].trim();
    if (blockers && blockers !== "None" && blockers !== "-") {
      result.blockers = [blockers];
    } else {
      result.blockers = [];
    }
  }
  const dateMatch = content.match(/Last [Uu]pdated[:\s]*(\d{4}-\d{2}-\d{2})/);
  if (dateMatch) {
    result.lastActivity = dateMatch[1];
  } else {
    result.lastActivity = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  }
  return result;
}
async function discoverApps(token) {
  const layers = ["foundational", "operational", "gateway"];
  const apps = [];
  for (const layer of layers) {
    const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${layer}?ref=${GITHUB_BRANCH}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github.v3+json"
      }
    });
    if (!response.ok)
      continue;
    const entries = await response.json();
    for (const entry of entries) {
      if (entry.type !== "dir")
        continue;
      if (entry.name.startsWith(".") || entry.name === "node_modules")
        continue;
      if (entry.name === "research" || entry.name === "shared")
        continue;
      const appPath = `${layer}/${entry.name}`;
      const statusPath = `${appPath}/STATUS.md`;
      const statusContent = await fetchFromGitHub(statusPath, token);
      if (statusContent) {
        const parsed = parseStatusFile(statusContent, appPath);
        apps.push({
          name: parsed.name || entry.name,
          path: appPath,
          layer,
          status: parsed.status || "placeholder",
          progress: parsed.progress || 0,
          currentWaypoint: parsed.currentWaypoint || null,
          waypointName: parsed.waypointName || null,
          blockers: parsed.blockers || [],
          lastActivity: parsed.lastActivity || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        });
      } else {
        apps.push({
          name: entry.name,
          path: appPath,
          layer,
          status: "placeholder",
          progress: 0,
          currentWaypoint: null,
          waypointName: null,
          blockers: [],
          lastActivity: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        });
      }
    }
  }
  return apps;
}
function calculateSummary(apps) {
  const totalApps = apps.length;
  const productionReady = apps.filter((a) => a.status === "ready").length;
  const inDevelopment = apps.filter((a) => a.status === "active").length;
  const skeleton = apps.filter((a) => a.status === "skeleton").length;
  const placeholder = apps.filter((a) => a.status === "placeholder").length;
  const overallProgress = apps.reduce((sum, a) => sum + a.progress, 0) / (totalApps || 1);
  return {
    totalApps,
    productionReady,
    inDevelopment,
    skeleton,
    placeholder,
    overallProgress: Math.round(overallProgress * 100) / 100
  };
}
async function saveToDynamoDB(status) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  await dynamodb.send(
    new import_client_dynamodb.PutItemCommand({
      TableName: DYNAMODB_TABLE,
      Item: (0, import_util_dynamodb.marshall)({
        pk: "ECOSYSTEM",
        sk: "STATUS",
        ...status.summary,
        lastUpdated: timestamp,
        gsi1pk: "ECOSYSTEM",
        gsi1sk: status.summary.overallProgress,
        gsi2pk: "SUMMARY",
        gsi2sk: timestamp
      })
    })
  );
  const appItems = Object.entries(status.apps).map(([path, app]) => ({
    PutRequest: {
      Item: (0, import_util_dynamodb.marshall)({
        pk: `APP#${path}`,
        sk: "STATUS",
        ...app,
        lastUpdated: timestamp,
        gsi1pk: app.layer,
        gsi1sk: app.progress,
        gsi2pk: app.status,
        gsi2sk: app.lastActivity
      })
    }
  }));
  for (let i = 0; i < appItems.length; i += 25) {
    const batch = appItems.slice(i, i + 25);
    await dynamodb.send(
      new import_client_dynamodb.BatchWriteItemCommand({
        RequestItems: {
          [DYNAMODB_TABLE]: batch
        }
      })
    );
  }
  await dynamodb.send(
    new import_client_dynamodb.PutItemCommand({
      TableName: DYNAMODB_TABLE,
      Item: (0, import_util_dynamodb.marshall)({
        pk: "ECOSYSTEM",
        sk: `HISTORY#${timestamp}`,
        ...status.summary,
        timestamp,
        ttl: Math.floor(Date.now() / 1e3) + 365 * 24 * 60 * 60
        // 1 year TTL
      })
    })
  );
}
async function saveToS3(status) {
  const date = /* @__PURE__ */ new Date();
  const datePath = `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
  await s3.send(
    new import_client_s3.PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: `snapshots/${datePath}/ecosystem-status.json`,
      Body: JSON.stringify(status, null, 2),
      ContentType: "application/json"
    })
  );
  await s3.send(
    new import_client_s3.PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: "snapshots/latest/ecosystem-status.json",
      Body: JSON.stringify(status, null, 2),
      ContentType: "application/json"
    })
  );
}
async function publishMetrics(status) {
  const timestamp = /* @__PURE__ */ new Date();
  const metrics = [
    {
      MetricName: "OverallProgress",
      Value: status.summary.overallProgress,
      Unit: "None"
    },
    {
      MetricName: "ProductionReadyApps",
      Value: status.summary.productionReady,
      Unit: "Count"
    },
    {
      MetricName: "ActiveBlockers",
      Value: Object.values(status.apps).reduce(
        (sum, app) => sum + app.blockers.length,
        0
      ),
      Unit: "Count"
    },
    {
      MetricName: "AppsByStatus",
      Value: status.summary.productionReady,
      Unit: "Count",
      Dimensions: [{ Name: "Status", Value: "ready" }]
    },
    {
      MetricName: "AppsByStatus",
      Value: status.summary.inDevelopment,
      Unit: "Count",
      Dimensions: [{ Name: "Status", Value: "active" }]
    },
    {
      MetricName: "AppsByStatus",
      Value: status.summary.skeleton,
      Unit: "Count",
      Dimensions: [{ Name: "Status", Value: "skeleton" }]
    },
    {
      MetricName: "AppsByStatus",
      Value: status.summary.placeholder,
      Unit: "Count",
      Dimensions: [{ Name: "Status", Value: "placeholder" }]
    }
  ];
  const layers = ["foundational", "operational", "gateway"];
  for (const layer of layers) {
    const layerApps = Object.values(status.apps).filter((a) => a.layer === layer);
    const layerProgress = layerApps.reduce((sum, a) => sum + a.progress, 0) / (layerApps.length || 1);
    metrics.push({
      MetricName: "LayerProgress",
      Value: layerProgress,
      Unit: "None",
      Dimensions: [{ Name: "Layer", Value: layer }]
    });
  }
  await cloudwatch.send(
    new import_client_cloudwatch.PutMetricDataCommand({
      Namespace: "EcosystemProgress",
      MetricData: metrics.map((m) => ({
        ...m,
        Timestamp: timestamp,
        Dimensions: [
          { Name: "Environment", Value: ENVIRONMENT },
          ...m.Dimensions || []
        ]
      }))
    })
  );
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  try {
    const token = await getGitHubToken();
    console.log("Discovering apps...");
    const apps = await discoverApps(token);
    console.log(`Found ${apps.length} apps`);
    const summary = calculateSummary(apps);
    const status = {
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      summary,
      apps: Object.fromEntries(apps.map((a) => [a.path, a]))
    };
    console.log("Saving to DynamoDB...");
    await saveToDynamoDB(status);
    console.log("Saving to S3...");
    await saveToS3(status);
    console.log("Publishing metrics...");
    await publishMetrics(status);
    console.log("Sync complete");
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Progress synced successfully",
        summary,
        appsProcessed: apps.length
      })
    };
  } catch (error) {
    console.error("Sync error:", error);
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
